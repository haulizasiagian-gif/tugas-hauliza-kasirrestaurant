# ==========================================
#       APLIKASI KASIR RESTORAN
# ==========================================

print("===================================")
print("       APLIKASI KASIR RESTORAN")
print("===================================")

# Daftar menu dan harga
menu = {
    1: ("Nasi Goreng", 25000),
    2: ("Mie Ayam", 15000),
    3: ("Ayam Geprek", 20000),
    4: ("Sate Ayam", 30000),
    5: ("Bakso", 18000)
}

# Inisialisasi total belanja
total = 0

# Perulangan pemesanan
while True:

    print("\n========== MENU MAKANAN ==========")
    for nomor, data in menu.items():
        print(f"{nomor}. {data[0]} - Rp{data[1]:,}")

    print("0. Selesai Memilih")
    print("=================================")

    pilihan = int(input("Pilih menu (0-5): "))

    # Jika memilih 0, pemesanan selesai
    if pilihan == 0:
        break

    # Memeriksa pilihan menu
    elif pilihan in menu:

        nama, harga = menu[pilihan]

        jumlah = int(input("Masukkan jumlah pesanan: "))

        if jumlah <= 0:
            print("Jumlah pesanan harus lebih dari 0!")
            continue

        subtotal = harga * jumlah
        total += subtotal

        print("\nPesanan berhasil ditambahkan!")
        print("Nama Makanan :", nama)
        print("Harga        : Rp", harga)
        print("Jumlah       :", jumlah)
        print("Subtotal     : Rp", subtotal)

    else:
        print("Pilihan menu tidak tersedia!")

# ==========================================
#             PERHITUNGAN DISKON
# ==========================================

if total > 200000:
    diskon = 0.20
else:
    diskon = 0

potongan = total * diskon
total_bayar = total - potongan

# ==========================================
#           STRUK PEMBAYARAN
# ==========================================

print("\n===================================")
print("          STRUK PEMBAYARAN")
print("===================================")
print("Total Belanja : Rp", total)
print("Diskon        :", int(diskon * 100), "%")
print("Potongan      : Rp", potongan)
print("-----------------------------------")
print("Total Bayar   : Rp", total_bayar)
print("===================================")
print("       TERIMA KASIH")
print("===================================")
